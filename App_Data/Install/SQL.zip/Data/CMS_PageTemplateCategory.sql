SET IDENTITY_INSERT [CMS_PageTemplateCategory] ON
INSERT INTO [CMS_PageTemplateCategory] ([CategoryID], [CategoryDisplayName], [CategoryParentID], [CategoryName], [CategoryGUID], [CategoryLastModified], [CategoryImagePath], [CategoryPath], [CategoryOrder], [CategoryLevel]) VALUES (43, N'All page templates', NULL, N'/', '532264bf-95e9-4035-b4ce-fe403c81781a', '20120913 12:08:03', N'', N'/', 1, 0)
SET IDENTITY_INSERT [CMS_PageTemplateCategory] OFF
